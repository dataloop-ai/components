const { defineConfig } = require('@vue/cli-service')
const ForkTsCheckerWebpackPlugin = require('fork-ts-checker-webpack-plugin')
const MiniCSSExtractPlugin = require('mini-css-extract-plugin')
const SimpleProgressWebpackPlugin = require('simple-progress-webpack-plugin')
const CompressionPlugin = require('compression-webpack-plugin')

module.exports = defineConfig({
    transpileDependencies: true,
    configureWebpack: (config) => {
        config.plugins.push(
            new SimpleProgressWebpackPlugin({
                format: 'minimal'
            })
        )
        // // get a reference to the existing ForkTsCheckerWebpackPlugin
        // const existingForkTsChecker = config.plugins.filter(
        //     (p) => p instanceof ForkTsCheckerWebpackPlugin
        // )[0]
        // // remove the existing ForkTsCheckerWebpackPlugin
        // // so that we can replace it with our modified version
        // config.plugins = config.plugins.filter(
        //     (p) => !(p instanceof ForkTsCheckerWebpackPlugin)
        // )
        // // copy the options from the original ForkTsCheckerWebpackPlugin
        // // instance and add the memoryLimit property
        // const forkTsCheckerOptions = existingForkTsChecker.options
        // forkTsCheckerOptions.memoryLimit = 6144
        // forkTsCheckerOptions.workers = 3
        // config.plugins.push(
        //     new ForkTsCheckerWebpackPlugin(forkTsCheckerOptions)
        // )

        // config.node.fs = 'empty'
        // config.module.rules.push({
        //     resourceQuery: /raw/,
        //     use: 'raw-loader'
        // })
        // // To avoid build warning. Remove once Winston is removed from dataloop utils
        // config.module.exprContextCritical = false

        // config.optimization.runtimeChunk = 'single'
        // config.optimization.splitChunks = {
        //     chunks: 'all',
        //     maxInitialRequests: Infinity,
        //     minSize: 0,
        //     cacheGroups: {
        //         vendor: {
        //             test: /[\\/]node_modules[\\/]/,
        //             name(module) {
        //                 // get the name. E.g. node_modules/packageName/not/this/part.js
        //                 // or node_modules/packageName
        //                 const packageName = module.context.match(
        //                     /[\\/]node_modules[\\/](.*?)([\\/]|$)/
        //                 )[1]

        //                 // npm package names are URL-safe, but some servers don't like @ symbols
        //                 return `npm.${packageName.replace('@', '')}`
        //             },
        //             reuseExistingChunk: true
        //         }
        //     }
        // }

        config.plugins.push(
            new MiniCSSExtractPlugin({
                filename: 'css/[name].[hash].css',
                chunkFilename: 'css/[id].[hash].css'
            })
        )

        // config.plugins.push(
        //     new CompressionPlugin({
        //         filename: '[path][base].gz',
        //         algorithm: 'gzip',
        //         test: /\.js$|\.css$|\.html$/,
        //         threshold: 10240,
        //         minRatio: 0.8
        //     })
        // )
    }
})
