<template>
    <div id="app">
        <dl-theme-provider :is-dark="isDarkMode">
            <DlComponentsDemo />
        </dl-theme-provider>
    </div>
</template>

<script lang="ts">
// @ts-skip

import { defineComponent } from 'vue-demi'
import { DlComponentsDemo } from '@dataloop/components'

export default defineComponent({
    name: 'App',
    components: {
        DlComponentsDemo
    },
    data() {
        return {
            isDarkMode: false
        }
    },
    methods: {}
})
</script>

<style scoped lang="scss">
#app {
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
}
.col {
    width: auto;
    display: flex;
    flex-wrap: wrap;
    min-width: 0;
    max-width: 100%;
    & > button,
    & > div.dl-chip {
        margin: 0 0 0 8px;
    }
}

.tooltip-container {
    width: 300px;
    height: 200px;
    overflow-y: scroll;
    margin: 10px auto;
}

.slider-container {
    margin: 10px auto;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}
</style>
