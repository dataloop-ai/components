import { defineConfig } from 'vite'
import { createVuePlugin as vue } from 'vite-plugin-vue2'

// https://vitejs.dev/config/
export default defineConfig({
    optimizeDeps: {
        include: ['lodash', 'flat', 'highlight.js']
    },
    plugins: [
        vue({
            jsx: true
        })
    ],
    server: { port: 3000 },
    resolve: {
        alias: {
            vue: 'vue/dist/vue.esm.js'
        }
    }
})
