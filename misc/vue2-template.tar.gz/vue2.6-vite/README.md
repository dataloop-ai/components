# Vue 2.6 + TypeScript + Vite

This a simple demo app that contains vue 2.6 class component and vite