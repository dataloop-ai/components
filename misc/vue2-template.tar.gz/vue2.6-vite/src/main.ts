import './style.css'
import Vue from 'vue'
import App from './App.vue'
import hljs from 'highlight.js';

new Vue(App).$mount('#app')
