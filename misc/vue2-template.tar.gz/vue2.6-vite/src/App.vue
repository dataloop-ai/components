<template>
  <DlComponentsDemo />
</template>

<script lang="ts">
import Vue from 'vue'
import Component from 'vue-class-component'
import { DlComponentsDemo } from '@dataloop-ai/components'

@Component({
  name: 'App',
  components: {
    DlComponentsDemo
  }
})
export default class App extends Vue {
}
</script>


<style scoped>
</style>
